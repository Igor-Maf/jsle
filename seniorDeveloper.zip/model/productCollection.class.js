function ProductCollection(config) {
    var config = config,
	    storage = [],
	    template = '<ul class="product"></ul>';

	this.add = function(product) {
		storage.push(product);
	}

	this.appendTo = function(elem) {
		var products = $(template);
		storage.forEach(function(one) {
			one.appendTo(products);
		});
		elem.append(products);
	}

	this.getProductsByType = function(type) {
		// Напишите метод самостоятельно. Должен возвращать массив товаров с типом type
	}

	return this;
}
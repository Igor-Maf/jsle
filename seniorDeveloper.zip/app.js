// Создаем экземпляры класса и передаем им конфиг

var firstProduct = new Product({
	title: 'Шапка ушанка',
	price: 1899,
	discount: 0.10,
	type: 'expensive'
});

var secondProduct = new Product({
	title: 'Валенки',
	price: 399,
	discount: 0.10,
	type: 'cheap'
});

var thirdProduct = new Product({
	title: 'Варежки',
	price: 199,
	discount: 0.10,
	type: 'cheap'
});

// Создем коллекцию

var collection = new ProductCollection();

collection.add(firstProduct);
collection.add(secondProduct);
collection.add(thirdProduct);

$(document).ready(function() {
    collection.appendTo($('body'));
});